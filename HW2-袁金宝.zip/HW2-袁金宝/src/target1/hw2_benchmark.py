import csv
import json
import time
from pathlib import Path

import ray
import requests
from transformers import AutoTokenizer


SERVER = "http://localhost:30000"

MODEL_PATH = (
    "/home/cxy0714/.cache/huggingface/hub/"
    "models--Qwen--Qwen3-0.6B/snapshots/"
    "c1899de289a04d12100db370d81485cdf75e47ca"
)

NUM_REQUESTS = 32
MAX_CONCURRENCY = 8

SHARED_PREFIX_LEN = 2048
SUFFIX_LEN = 64
PROMPT_LEN = 2112

MAX_NEW_TOKENS = 16
SAMPLING_SEED = 2026

ROOT = Path(__file__).resolve().parents[2]
RESULT_ROOT = ROOT / "results"/ "target1"


# --------------------------------------------------
# 请求 SGLang
# --------------------------------------------------

@ray.remote(num_cpus=0.1)
def send_request(request_id, group, input_ids):

    payload = {
        "input_ids": input_ids,

        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SAMPLING_SEED,
        },

        "stream": True,
    }

    start = time.perf_counter()

    first_token_time = None
    final_meta = None
    status = "ERROR"
    error = ""

    try:
        with requests.post(
            SERVER + "/generate",
            json=payload,
            stream=True,
            timeout=300,
        ) as response:

            status = response.status_code

            if response.status_code != 200:
                return {
                    "request_id": request_id,
                    "group": group,
                    "status": status,
                    "prompt_tokens": 0,
                    "cached_tokens": 0,
                    "actual_prefill_tokens": 0,
                    "completion_tokens": 0,
                    "ttft_ms": 0,
                    "tpot_ms": 0,
                    "e2e_latency_ms": 0,
                    "server_e2e_ms": 0,
                    "error": response.text[:300],
                }

            # chunk_size=1，避免 requests 自己缓冲太多数据，
            # 使客户端 TTFT 测量更接近首个 SSE 到达时间。
            for line in response.iter_lines(
                chunk_size=1,
                decode_unicode=True
            ):

                if not line:
                    continue

                if not line.startswith("data:"):
                    continue

                content = line[5:].strip()

                if content == "[DONE]":
                    break

                data = json.loads(content)

                meta = data.get("meta_info", {})

                completion_tokens = meta.get(
                    "completion_tokens", 0
                )

                # 第一条生成 token 到达客户端
                if (
                    first_token_time is None
                    and completion_tokens >= 1
                ):
                    first_token_time = time.perf_counter()

                final_meta = meta

        end = time.perf_counter()

        if first_token_time is None:
            raise RuntimeError(
                "没有收到生成 token"
            )

        if final_meta is None:
            raise RuntimeError(
                "没有收到 meta_info"
            )

        prompt_tokens = final_meta.get(
            "prompt_tokens",
            len(input_ids)
        )

        cached_tokens = final_meta.get(
            "cached_tokens",
            0
        ) or 0

        completion_tokens = final_meta.get(
            "completion_tokens",
            0
        )

        ttft = first_token_time - start
        e2e = end - start

        if completion_tokens > 1:
            tpot = (
                e2e - ttft
            ) / (completion_tokens - 1)
        else:
            tpot = 0

        server_e2e = final_meta.get(
            "e2e_latency",
            0
        ) or 0

        return {
            "request_id": request_id,
            "group": group,
            "status": status,
            "prompt_tokens": prompt_tokens,
            "cached_tokens": cached_tokens,

            "actual_prefill_tokens":
                prompt_tokens - cached_tokens,

            "completion_tokens":
                completion_tokens,

            "ttft_ms":
                round(ttft * 1000, 3),

            "tpot_ms":
                round(tpot * 1000, 3),

            "e2e_latency_ms":
                round(e2e * 1000, 3),

            "server_e2e_ms":
                round(server_e2e * 1000, 3),

            "error": "",
        }

    except Exception as e:

        return {
            "request_id": request_id,
            "group": group,
            "status": status,
            "prompt_tokens": 0,
            "cached_tokens": 0,
            "actual_prefill_tokens": 0,
            "completion_tokens": 0,
            "ttft_ms": 0,
            "tpot_ms": 0,
            "e2e_latency_ms": 0,
            "server_e2e_ms": 0,
            "error": str(e),
        }


# --------------------------------------------------
# percentile
# --------------------------------------------------

def percentile(values, p):

    values = sorted(values)

    if not values:
        return 0

    if len(values) == 1:
        return values[0]

    pos = (len(values) - 1) * p

    low = int(pos)
    high = min(low + 1, len(values) - 1)

    fraction = pos - low

    return (
        values[low] * (1 - fraction)
        + values[high] * fraction
    )


# --------------------------------------------------
# flush cache
# --------------------------------------------------

def flush_cache():

    response = requests.post(
        SERVER + "/flush_cache",
        timeout=30
    )

    print(
        "flush_cache:",
        response.status_code,
        response.text
    )

    if response.status_code != 200:
        raise RuntimeError(
            "flush_cache 请求失败"
        )


# --------------------------------------------------
# 单条同步请求，用于预热
# --------------------------------------------------

def warmup_request(input_ids):

    payload = {
        "input_ids": input_ids,

        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SAMPLING_SEED,
        },

        "stream": True,
    }

    with requests.post(
        SERVER + "/generate",
        json=payload,
        stream=True,
        timeout=300,
    ) as response:

        response.raise_for_status()

        for line in response.iter_lines(
            chunk_size=1,
            decode_unicode=True
        ):
            if line.strip() == "data: [DONE]":
                break


# --------------------------------------------------
# 构造合法 token
# --------------------------------------------------

def build_token_pool():

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_PATH,
        local_files_only=True
    )

    special_ids = set(
        tokenizer.all_special_ids
    )

    ids = sorted(
        set(tokenizer.get_vocab().values())
        - special_ids
    )

    # 跳过特别小的一段 id，
    # 从中间选择普通合法 token。
    ids = ids[1000:]

    if len(ids) < 5000:
        raise RuntimeError(
            "可用 token 数不足"
        )

    return ids


# --------------------------------------------------
# 两组 workload
# --------------------------------------------------

def build_workloads(token_pool):

    # -------- 共享前缀组 --------

    shared_prefix = [
        token_pool[
            (i * 17 + 100) % len(token_pool)
        ]
        for i in range(SHARED_PREFIX_LEN)
    ]

    shared_requests = []

    # 让每条请求 suffix 的第一个 token 不同，
    # 避免在 2048 公共前缀之后继续意外命中。
    suffix_first_tokens = token_pool[6000:6032]

    for req_id in range(NUM_REQUESTS):

        suffix = [
            suffix_first_tokens[req_id]
        ]

        suffix.extend(
            token_pool[
                (
                    9000
                    + req_id * 97
                    + j * 13
                ) % len(token_pool)
            ]
            for j in range(SUFFIX_LEN - 1)
        )

        prompt = (
            shared_prefix + suffix
        )

        assert len(prompt) == PROMPT_LEN

        shared_requests.append(prompt)

    # -------- 分散前缀组 --------

    dispersed_requests = []

    # 32 个完全不同的第一个 token
    first_tokens = token_pool[12000:12032]

    common_body = [
        token_pool[
            (15000 + j * 19)
            % len(token_pool)
        ]
        for j in range(PROMPT_LEN - 1)
    ]

    for req_id in range(NUM_REQUESTS):

        prompt = [
            first_tokens[req_id]
        ] + common_body

        assert len(prompt) == PROMPT_LEN

        dispersed_requests.append(prompt)

    return (
        shared_prefix,
        shared_requests,
        dispersed_requests,
    )


# --------------------------------------------------
# 保持最多 8 条请求同时运行
# --------------------------------------------------

def run_group(
    group_name,
    requests_list,
):

    print()
    print("=" * 70)
    print(
        f"开始测量 {group_name}"
    )
    print("=" * 70)

    start_wall = time.perf_counter()

    results = []

    next_request = 0
    pending = []

    # 先提交最多 8 条
    while (
        next_request < NUM_REQUESTS
        and len(pending) < MAX_CONCURRENCY
    ):

        ref = send_request.remote(
            next_request + 1,
            group_name,
            requests_list[next_request],
        )

        pending.append(ref)

        next_request += 1

    # 每完成一条，再补一条，
    # 始终保证最多 8 条在运行。
    while pending:

        done, pending = ray.wait(
            pending,
            num_returns=1
        )

        result = ray.get(done[0])

        results.append(result)

        print(
            f"[{group_name}] "
            f"{result['request_id']:02d}/32 | "
            f"status={result['status']} | "
            f"cached={result['cached_tokens']} | "
            f"prefill={result['actual_prefill_tokens']} | "
            f"TTFT={result['ttft_ms']:.3f}ms | "
            f"E2E={result['e2e_latency_ms']:.3f}ms"
        )

        if next_request < NUM_REQUESTS:

            ref = send_request.remote(
                next_request + 1,
                group_name,
                requests_list[next_request],
            )

            pending.append(ref)

            next_request += 1

    wall_time = (
        time.perf_counter()
        - start_wall
    )

    results.sort(
        key=lambda x: x["request_id"]
    )

    return results, wall_time


# --------------------------------------------------
# 写逐请求 CSV + summary
# --------------------------------------------------

def save_results(
    group_name,
    results,
    wall_time,
):

    out_dir = (
        RESULT_ROOT / group_name
    )

    out_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    csv_path = (
        out_dir / "requests.csv"
    )

    fields = list(
        results[0].keys()
    )

    with open(
        csv_path,
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fields
        )

        writer.writeheader()
        writer.writerows(results)

    successful = [
        r for r in results
        if r["status"] == 200
    ]

    success_rate = (
        len(successful)
        / len(results)
    )

    prompt_sum = sum(
        r["prompt_tokens"]
        for r in successful
    )

    cached_sum = sum(
        r["cached_tokens"]
        for r in successful
    )

    prefill_sum = sum(
        r["actual_prefill_tokens"]
        for r in successful
    )

    completion_sum = sum(
        r["completion_tokens"]
        for r in successful
    )

    cache_hit_rate = (
        cached_sum / prompt_sum
        if prompt_sum else 0
    )

    ttfts = [
        r["ttft_ms"]
        for r in successful
    ]

    tpots = [
        r["tpot_ms"]
        for r in successful
    ]

    e2es = [
        r["e2e_latency_ms"]
        for r in successful
    ]

    summary = {
        "group": group_name,

        "requests":
            len(results),

        "successful":
            len(successful),

        "success_rate":
            success_rate,

        "wall_time_s":
            wall_time,

        "request_throughput_rps":
            (
                len(successful)
                / wall_time
            ),

        "output_throughput_tokens_per_s":
            (
                completion_sum
                / wall_time
            ),

        "total_prompt_tokens":
            prompt_sum,

        "total_cached_tokens":
            cached_sum,

        "cache_hit_rate":
            cache_hit_rate,

        "actual_prefill_tokens":
            prefill_sum,

        "ttft_p50_ms":
            percentile(ttfts, 0.50),

        "ttft_p95_ms":
            percentile(ttfts, 0.95),

        "tpot_p50_ms":
            percentile(tpots, 0.50),

        "tpot_p95_ms":
            percentile(tpots, 0.95),

        "e2e_p50_ms":
            percentile(e2es, 0.50),

        "e2e_p95_ms":
            percentile(e2es, 0.95),
    }

    summary_path = (
        out_dir / "summary.json"
    )

    with open(
        summary_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            indent=2,
            ensure_ascii=False
        )

    return summary


# --------------------------------------------------
# 打印最终对照表
# --------------------------------------------------

def print_summary(shared, dispersed):

    print()
    print("=" * 110)

    print(
        "Metric".ljust(34),
        "shared_prefix".rjust(20),
        "dispersed_prefix".rjust(22)
    )

    print("-" * 110)

    rows = [
        (
            "Success rate",
            f"{shared['success_rate']*100:.1f}%",
            f"{dispersed['success_rate']*100:.1f}%"
        ),

        (
            "Request throughput (req/s)",
            f"{shared['request_throughput_rps']:.3f}",
            f"{dispersed['request_throughput_rps']:.3f}"
        ),

        (
            "Output throughput (tok/s)",
            f"{shared['output_throughput_tokens_per_s']:.3f}",
            f"{dispersed['output_throughput_tokens_per_s']:.3f}"
        ),

        (
            "Cache hit rate",
            f"{shared['cache_hit_rate']*100:.2f}%",
            f"{dispersed['cache_hit_rate']*100:.2f}%"
        ),

        (
            "Actual Prefill tokens",
            str(shared['actual_prefill_tokens']),
            str(dispersed['actual_prefill_tokens'])
        ),

        (
            "TTFT p50 (ms)",
            f"{shared['ttft_p50_ms']:.3f}",
            f"{dispersed['ttft_p50_ms']:.3f}"
        ),

        (
            "TTFT p95 (ms)",
            f"{shared['ttft_p95_ms']:.3f}",
            f"{dispersed['ttft_p95_ms']:.3f}"
        ),

        (
            "TPOT p50 (ms/token)",
            f"{shared['tpot_p50_ms']:.3f}",
            f"{dispersed['tpot_p50_ms']:.3f}"
        ),

        (
            "TPOT p95 (ms/token)",
            f"{shared['tpot_p95_ms']:.3f}",
            f"{dispersed['tpot_p95_ms']:.3f}"
        ),

        (
            "E2E p50 (ms)",
            f"{shared['e2e_p50_ms']:.3f}",
            f"{dispersed['e2e_p50_ms']:.3f}"
        ),

        (
            "E2E p95 (ms)",
            f"{shared['e2e_p95_ms']:.3f}",
            f"{dispersed['e2e_p95_ms']:.3f}"
        ),
    ]

    for name, a, b in rows:

        print(
            name.ljust(34),
            a.rjust(20),
            b.rjust(22)
        )

    print("=" * 110)


def main():

    print(
        "加载 tokenizer 并构造 workload..."
    )

    token_pool = build_token_pool()

    (
        shared_prefix,
        shared_requests,
        dispersed_requests,
    ) = build_workloads(token_pool)

    print(
        f"共享组：32 × "
        f"{len(shared_requests[0])} tokens"
    )

    print(
        f"分散组：32 × "
        f"{len(dispersed_requests[0])} tokens"
    )

    ray.init(
        ignore_reinit_error=True
    )

    # 先让 Ray worker 起来，
    # 避免第一次正式请求包含 worker 启动开销。
    @ray.remote(num_cpus=0.1)
    def ray_warmup():
        return True

    ray.get([
        ray_warmup.remote()
        for _ in range(MAX_CONCURRENCY)
    ])

    # --------------------------------
    # 服务短请求预热
    # --------------------------------

    print()
    print("进行服务短请求预热...")

    warmup_request(
        token_pool[20000:20008]
    )

    print("服务预热完成。")

    # --------------------------------
    # 共享前缀组
    # --------------------------------

    print()
    print("清空缓存...")

    flush_cache()

    # 按作业要求：
    # 发送一条包含 2048 token 公共前缀的预热请求
    print(
        "发送 2048-token "
        "共享前缀预热请求..."
    )

    warmup_request(shared_prefix)

    print("共享前缀预热完成。")

    shared_results, shared_wall = (
        run_group(
            "shared_prefix",
            shared_requests,
        )
    )

    shared_summary = save_results(
        "shared_prefix",
        shared_results,
        shared_wall,
    )

    # 确保这一组全部结束以后再 flush
    print()
    print("共享组结束，清空缓存...")

    flush_cache()

    # --------------------------------
    # 分散前缀组
    # --------------------------------

    dispersed_results, dispersed_wall = (
        run_group(
            "dispersed_prefix",
            dispersed_requests,
        )
    )

    dispersed_summary = save_results(
        "dispersed_prefix",
        dispersed_results,
        dispersed_wall,
    )

    # --------------------------------
    # 保存总汇总
    # --------------------------------

    combined = {
        "shared_prefix":
            shared_summary,

        "dispersed_prefix":
            dispersed_summary,
    }

    with open(
        RESULT_ROOT / "summary.json",
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            combined,
            f,
            indent=2,
            ensure_ascii=False
        )

    print_summary(
        shared_summary,
        dispersed_summary
    )

    print()
    print(
        "结果保存在：",
        RESULT_ROOT
    )

    ray.shutdown()


if __name__ == "__main__":
    main()
