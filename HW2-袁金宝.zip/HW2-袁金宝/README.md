# HW2：SGLang Prefix Cache 实验与源码流程阅读

本次作业包含两个部分：

- 任务一：测量 SGLang Prefix Cache 对共享前缀请求的影响；
- 任务二：阅读 SGLang v0.5.14 中一条 `/generate` 请求的主要处理流程。

## 1. 实验环境

- 操作系统：WSL2 Ubuntu 22.04
- Python：3.10
- SGLang：0.5.14
- Ray：2.56.0
- 模型：Qwen/Qwen3-0.6B
- 推理设备：CUDA
- GPU：NVIDIA GeForce RTX 5060
- GPU 显存：8151 MiB（约 8 GB）
- NVIDIA Driver：592.01
- CUDA Version：13.1

本实验中 SGLang 的 Radix Cache 保持开启。服务日志中对应配置为：

```text
disable_radix_cache=False
```

可以使用下面的命令检查主要软件版本：

```bash
python --version
python -c "import sglang; print(sglang.__version__)"
python -c "import ray; print(ray.__version__)"
nvidia-smi
```

## 2. 环境安装

实验使用 Python 虚拟环境：

```bash
python3 -m venv ~/work/venv
source ~/work/venv/bin/activate
python -m pip install -U pip
pip install "sglang[all]==0.5.14" "ray==2.56.0"
```

模型使用本地 HuggingFace 缓存中的 Qwen3-0.6B。若已经下载模型，可直接使用本地 snapshot 路径启动，避免网络问题。

## 3. 启动 SGLang

先进入虚拟环境：

```bash
source ~/work/venv/bin/activate
cd ~/work/HW2
```

本次实验实际使用的启动命令为：

```bash
python -m sglang.launch_server \
  --model-path /home/cxy0714/.cache/huggingface/hub/models--Qwen--Qwen3-0.6B/snapshots/c1899de289a04d12100db370d81485cdf75e47ca \
  --host 0.0.0.0 \
  --port 30000
```

服务启动后默认地址为：

```text
http://127.0.0.1:30000
```

实验使用原生 `/generate` 接口发送 `input_ids`，并采用流式响应。

## 4. 任务一实验设置

两组 workload 均包含 32 条正式测量请求，最大并发数为 8，统一使用：

```text
temperature = 0
max_new_tokens = 16
ignore_eos = true
sampling_seed = 2026
```

共享前缀组：

- 每条请求输入长度为 2112 token；
- 前 2048 token 完全相同；
- 后 64 token 为各请求独立后缀；
- 正式测量前额外发送一次共享前缀预热请求。

分散前缀组：

- 每条请求输入长度同样为 2112 token；
- 每条请求首 token 不同；
- 不进行共享前缀预热。

每组实验前都会等待已有请求完成，并调用 `/flush_cache` 清空缓存。

## 5. 运行实验

实验脚本位于：

```text
src/target1/hw2_benchmark.py
```

在 SGLang 服务已经启动的情况下，另开一个终端执行：

```bash
source ~/work/venv/bin/activate
cd ~/work/HW2
python src/target1/hw2_benchmark.py
```

脚本主要完成以下工作：

1. 构造共享前缀组和分散前缀组请求；
2. 控制请求数量和最大并发数；
3. 在每组实验前清空缓存；
4. 发送流式 `/generate` 请求；
5. 记录每条请求的 `cached_tokens`、TTFT、TPOT、E2E 等数据；
6. 汇总两组实验结果。

## 6. 结果目录

本次实验结果保存在 `results/` 下。实际保留的第一次完整实验结果为：

```text
results/
└── target1/
    ├── shared_prefix/
    ├── dispersed_prefix/
    └── summary.json
```

其中：

- `shared_prefix/`：共享前缀组的逐请求结果；
- `dispersed_prefix/`：分散前缀组的逐请求结果；
- `summary.json`：两组实验的汇总指标。

`report.pdf` 中任务一的结果表对应 `results/target1/summary.json`，逐请求数据可在两个组对应的目录中查看。

本次报告中使用的主要汇总结果为：

| 指标 | shared_prefix | dispersed_prefix |
|---|---:|---:|
| Success rate | 100% | 100% |
| Request throughput | 54.749 req/s | 9.060 req/s |
| Cache hit rate | 96.97% | 0% |
| Actual Prefill tokens | 2048 | 67584 |
| TTFT p50 | 43.967 ms | 458.909 ms |
| TTFT p95 | 50.205 ms | 692.197 ms |
| TPOT p50 | 6.173 ms/token | 27.630 ms/token |
| TPOT p95 | 7.436 ms/token | 46.739 ms/token |
| E2E p50 | 138.288 ms | 889.767 ms |
| E2E p95 | 142.398 ms | 907.203 ms |

## 7. 任务二源码阅读

任务二没有修改 SGLang 源码，主要沿着一条 `/generate` 请求的处理流程进行阅读。

主要关注的源码文件包括：

```text
sglang/srt/managers/tokenizer_manager.py
sglang/srt/managers/scheduler.py
sglang/srt/managers/schedule_policy.py
sglang/srt/managers/schedule_batch.py
sglang/srt/managers/tp_worker.py
sglang/srt/model_executor/model_runner.py
sglang/srt/mem_cache/radix_cache.py
sglang/srt/mem_cache/common.py
sglang/srt/managers/scheduler_components/batch_result_processor.py
sglang/srt/managers/scheduler_components/output_streamer.py
sglang/srt/managers/detokenizer_manager.py
```

主要调用链整理在 `report.pdf` 的任务二部分。

## 8. 文件说明

```text
HW2-姓名/
├── README.md
├── report.pdf
├── AI 使用说明情况（第二次挑战）.pdf
├── src/
│   └── hw2_benchmark.py
└── results/
    └── target1/
        ├── shared_prefix/
        ├── dispersed_prefix/
        └── summary.json
```

其中：

- `README.md`：环境、安装、启动、实验回放和结果说明；
- `report.pdf`：任务一实验结果与分析、任务二源码流程；
- `AI 使用说明情况（第二次挑战）.pdf`：本次作业中的 AI 使用情况；
- `src/target1/hw2_benchmark.py`：任务一实验脚本；
- `results/`：任务一原始结果和汇总结果。
