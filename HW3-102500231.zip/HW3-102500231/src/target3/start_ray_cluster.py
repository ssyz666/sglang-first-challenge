import json
import signal
import time

import ray
from ray.cluster_utils import Cluster

cluster = Cluster()

# 1 个 head 节点
cluster.add_node(
    num_cpus=1,
    num_gpus=0,
)

# 4 个逻辑 worker 节点
for i in range(4):
    cluster.add_node(
        num_cpus=8,
        num_gpus=0,
        resources={
            "serve_worker": 1,
            f"worker_{i}": 1,
        },
    )

ray.init(address=cluster.address)

nodes = [n for n in ray.nodes() if n["Alive"]]

print("\n===== Ray nodes =====")
for n in nodes:
    print(
        "node_id =", n["NodeID"],
        "\nresources =", n["Resources"],
        "\n"
    )

# 保存“节点 -> SGLang 后端”的对应关系，后面 Serve Replica 会用
mapping = {}

for n in nodes:
    resources = n["Resources"]

    for i in range(4):
        if f"worker_{i}" in resources:
            mapping[n["NodeID"]] = f"http://127.0.0.1:{30000 + i}"

with open(
    "/root/autodl-tmp/HW3/src/target3/node_backend_map.json",
    "w",
) as f:
    json.dump(mapping, f, indent=2)

print("===== node -> backend =====")
print(json.dumps(mapping, indent=2))

print("\nRay cluster is running.")
print("Do not close this process. Press Ctrl+C only when you want to stop it.")

try:
    signal.pause()
except KeyboardInterrupt:
    print("Stopping Ray cluster...")
    ray.shutdown()
    cluster.shutdown()
