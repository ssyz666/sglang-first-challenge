from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter


class AffinityLoadAwareRouter(ConsistentHashRouter):
    """
    Prefix-affinity-first router with load-aware spillover.

    Normal requests stay on their consistent-hash primary replica.
    When the primary queue reaches spillover_threshold, route to the
    least-loaded non-primary replica instead.
    """

    def initialize_state(self, **kwargs):
        self._spillover_threshold = int(
            kwargs.get("spillover_threshold", 24)
        )

        # We manage fallback ourselves, so the parent hash router
        # only needs to return the deterministic primary.
        super().initialize_state(
            num_virtual_nodes=int(kwargs.get("num_virtual_nodes", 100)),
            num_fallback_replicas=0,
        )

    async def choose_replicas(
        self,
        candidate_replicas,
        pending_request=None,
    ):
        if not candidate_replicas:
            return []

        if pending_request is not None:
            pending_request.routing_context.should_backoff = True

        routing_key = self._routing_key(pending_request)

        if routing_key is None:
            return [candidate_replicas]

        ranked_ids = self._lookup_ranked_replicas(routing_key)

        if not ranked_ids:
            return [candidate_replicas]

        primary_id = ranked_ids[0]
        primary = self._replicas.get(primary_id)

        if primary is None:
            return [candidate_replicas]

        fallbacks = [
            replica
            for replica in candidate_replicas
            if replica.replica_id != primary_id
        ]

        # Read Ray Serve's queue-length signal.
        primary_queue_len = self.replica_queue_len_cache.get(primary_id)

        # Preserve affinity while the primary is below the threshold.
        if (
            primary_queue_len is None
            or primary_queue_len < self._spillover_threshold
        ):
            # Primary first. If it becomes unavailable/full while routing,
            # fall back to the least-loaded alternative.
            return [[primary], fallbacks]

        # Primary is becoming a hotspot.
        # Put all non-primary replicas in one rank; Ray Serve's base
        # selection logic chooses the one with the smallest queue length.
        if fallbacks:
            return [fallbacks, [primary]]

        return [[primary]]
