import json
import time

import httpx
import ray
from ray import serve
from ray.serve.config import RequestRouterConfig
from ray.serve.config import ProxyLocation
from starlette.requests import Request
from starlette.responses import StreamingResponse


MAP_PATH = "/root/autodl-tmp/HW3/src/target3/node_backend_map.json"


@serve.deployment(
    num_replicas=4,
    max_ongoing_requests=32,
    request_router_config=RequestRouterConfig(
        request_router_class=(
            "hybrid_router."
            "AffinityLoadAwareRouter"
        ),
        request_router_kwargs={
            "num_virtual_nodes": 100,
            "spillover_threshold": 24,
        },
    ),
    max_replicas_per_node=1,
    ray_actor_options={
        "num_cpus": 1,
        "resources": {"serve_worker": 1},
    },
)
class SGLangProxy:
    def __init__(self):
        self.node_id = ray.get_runtime_context().get_node_id()

        with open(MAP_PATH, "r") as f:
            mapping = json.load(f)

        if self.node_id not in mapping:
            raise RuntimeError(
                f"Replica placed on unexpected node: {self.node_id}"
            )

        self.backend = mapping[self.node_id]
        self.replica_id = serve.get_replica_context().replica_tag
        self.client = httpx.AsyncClient(timeout=None)

        print(
            f"Replica {self.replica_id} "
            f"node={self.node_id} "
            f"backend={self.backend}",
            flush=True,
        )

    async def __call__(self, request: Request):
        body = await request.body()

        # 作业要求必须继续向 SGLang 转发这三个请求头
        forward_headers = {
            "Content-Type": request.headers.get(
                "content-type", "application/json"
            ),
        }

        for name in (
            "X-Session-Id",
            "X-Workload-Request-ID",
            "X-Prefix-Family",
        ):
            value = request.headers.get(name)
            if value is not None:
                forward_headers[name] = value

        upstream_request = self.client.build_request(
            "POST",
            f"{self.backend}/generate",
            content=body,
            headers=forward_headers,
        )

        upstream = await self.client.send(
            upstream_request,
            stream=True,
        )

        async def stream_body():
            try:
                async for chunk in upstream.aiter_raw():
                    yield chunk
            finally:
                await upstream.aclose()

        # 作业要求客户端必须能够知道实际经过的
        # Replica、Ray node 和 SGLang backend
        response_headers = {
            "X-Ray-Replica-ID": str(self.replica_id),
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend,
        }

        content_type = upstream.headers.get("content-type")
        if content_type:
            response_headers["Content-Type"] = content_type

        return StreamingResponse(
            stream_body(),
            status_code=upstream.status_code,
            headers=response_headers,
            media_type=None,
        )


if __name__ == "__main__":
    ray.init(address="auto")

    # 这些逻辑 Ray 节点都位于同一物理机，
    # 所以只在 head 节点启动一个 HTTP Proxy。
    serve.start(
        proxy_location=ProxyLocation.HeadOnly,
        http_options={
            "host": "127.0.0.1",
            "port": 8000,
        },
    )

    serve.run(
        SGLangProxy.bind(),
        name="routing",
        route_prefix="/generate",
    )

    print("D_improved is running at http://127.0.0.1:8000/generate")
    print("max_ongoing_requests = 32")

    while True:
        time.sleep(3600)
