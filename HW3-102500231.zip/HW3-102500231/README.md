# HW3：Ray Serve 路由策略比较与改进

本次挑战主要完成 Ray Serve 四副本服务的搭建，并在固定 workload 下比较默认 P2C、不同 `max_ongoing_requests`、Consistent Hash 以及自定义负载感知路由策略的表现。

## 1. 实验环境

- 操作系统：Ubuntu 22.04
- Python：3.10
- GPU：4 × NVIDIA GeForce RTX 3080 Ti 12GB
- SGLang：0.5.14
- Ray：2.56.0
- PyTorch：2.11.0+cu130
- grpcio：1.81.1
- protobuf：6.33.6
- 模型：Qwen3-0.6B
- 模型路径：`/root/autodl-tmp/HW3/models/Qwen3-0.6B`

实验在同一台四卡服务器上启动 4 个独立 SGLang 服务，并使用 `ray.cluster_utils.Cluster` 创建 1 个逻辑 head 节点和 4 个逻辑 worker 节点。

整体结构：

~~~text
Client
  ↓
Ray Serve HTTP Proxy
  ↓
Replica 0 / Replica 1 / Replica 2 / Replica 3
  ↓           ↓           ↓           ↓
SGLang 0    SGLang 1    SGLang 2    SGLang 3
GPU 0       GPU 1       GPU 2       GPU 3
~~~

每个 Ray Serve Replica 位于不同 worker 节点，并根据 `node_backend_map.json` 固定转发到对应的 SGLang backend。

## 2. 环境安装

进入项目目录并创建虚拟环境：

~~~bash
cd /root/autodl-tmp/HW3

python3 -m venv venv
source venv/bin/activate

python -m pip install -U pip
pip install "sglang==0.5.14" "ray==2.56.0"
~~~

检查环境：

~~~bash
python --version
python -c "import ray; print(ray.__version__)"
python -c "import sglang; print(sglang.__version__)"
python -c "import torch; print(torch.__version__)"
nvidia-smi
~~~

## 3. 启动四个 SGLang Backend

四个 SGLang 服务分别使用：

~~~text
GPU 0 -> 127.0.0.1:30000
GPU 1 -> 127.0.0.1:30001
GPU 2 -> 127.0.0.1:30002
GPU 3 -> 127.0.0.1:30003
~~~

基本启动形式：

~~~bash
CUDA_VISIBLE_DEVICES=0 python -m sglang.launch_server \
  --model-path /root/autodl-tmp/HW3/models/Qwen3-0.6B \
  --host 127.0.0.1 \
  --port 30000
~~~

其余三个服务分别修改 GPU 和端口：

~~~text
GPU 1 -> 30001
GPU 2 -> 30002
GPU 3 -> 30003
~~~

实验过程中使用 `screen` 保持四个 SGLang 服务后台运行。

检查服务：

~~~bash
for p in 30000 30001 30002 30003; do
  curl -s http://127.0.0.1:$p/v1/models
done
~~~

每轮实验前清空四个 backend 的 KV cache：

~~~bash
for p in 30000 30001 30002 30003; do
  echo "===== flush $p ====="
  curl -s -w "\nHTTP %{http_code}\n" \
    -X POST http://127.0.0.1:$p/flush_cache
done
~~~

## 4. 启动 Ray 逻辑集群

Ray 集群脚本：

~~~text
src/target3/start_ray_cluster.py
~~~

该脚本创建：

~~~text
1 × head node
4 × logical worker node
~~~

4 个 worker 使用 `worker_0`、`worker_1`、`worker_2`、`worker_3` 资源标签，并具有统一的 `serve_worker` 资源。

运行：

~~~bash
cd /root/autodl-tmp/HW3
source venv/bin/activate

ulimit -n 65535
python src/target3/start_ray_cluster.py
~~~

实验时需要提高文件描述符限制：

~~~bash
ulimit -n 65535
~~~

否则在高并发 workload 下可能出现 connection reset、server disconnected 等连接错误。

## 5. Ray Serve 服务

所有实验组均部署 4 个 Ray Serve Replica，每个 Replica 位于不同的逻辑 worker 节点，并固定对应一个独立 SGLang backend。

统一 HTTP 入口：

~~~text
POST http://127.0.0.1:8000/generate
~~~

请求中的以下 header 会继续转发给 SGLang：

~~~text
X-Session-Id
X-Workload-Request-ID
X-Prefix-Family
~~~

Serve 返回时附加：

~~~text
X-Ray-Replica-ID
X-Ray-Node-ID
X-SGLang-Backend
~~~

这些 header 用于确认请求实际经过的 Replica、Node 和 SGLang backend。

### 5.1 A：默认 P2C

脚本：

~~~text
src/target3/serve_a.py
~~~

配置：

~~~text
router = p2c
max_ongoing_requests = 5
~~~

启动：

~~~bash
python src/target3/serve_a.py
~~~

### 5.2 B：调整 max_ongoing_requests

测试两个非默认候选值：

~~~text
B16: max_ongoing_requests = 16
B32: max_ongoing_requests = 32
~~~

对应脚本：

~~~text
src/target3/serve_b16.py
src/target3/serve_b32.py
~~~

根据吞吐量与延迟，最终选择：

~~~text
max_ongoing_requests = 32
~~~

### 5.3 C：Consistent Hash

脚本：

~~~text
src/target3/serve_c.py
~~~

配置：

~~~text
router = ConsistentHashRouter
max_ongoing_requests = 32
num_virtual_nodes = 100
num_fallback_replicas = 0
~~~

workload 中的 `X-Session-Id` 使用 prefix family，因此同一个 prefix family 会稳定路由到同一个 Replica，从而提高 SGLang Prefix Cache 的复用率。

### 5.4 D：Affinity + Load-aware Spillover

自定义 Router：

~~~text
src/target3/hybrid_router.py
~~~

Deployment：

~~~text
src/target3/serve_d.py
~~~

配置：

~~~text
max_ongoing_requests = 32
num_virtual_nodes = 100
spillover_threshold = 24
~~~

D 的主要路由规则为：

1. 根据 `session_id` 使用 consistent hash 找到 affinity primary；
2. primary 当前负载较低时，优先继续使用 primary，保留 Prefix Cache locality；
3. primary queue length 达到较高水平后，允许请求 spill over 到其他 Replica；
4. fallback Replica 根据 Ray Serve 当前 queue length 选择负载较低的节点。

因此 D 的目标不是完全放弃 affinity，而是在缓存复用和负载均衡之间进行折中。

## 6. 固定 Workload

workload 位于：

~~~text
26fall-HW-data/workloads/hw2/target3-routing-policies/
~~~

使用文件：

~~~text
mooncake_prefix_workload_v2_seed2026.jsonl
~~~

SHA256：

~~~text
f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03
~~~

数据包含：

~~~text
64 个 prefix families
64 条 warmup requests
2048 条 measured requests
~~~

流量由三个阶段组成：

~~~text
steady
burst
recovery
~~~

A～D 所有实验均使用完全相同的 workload，不修改请求、到达时间和请求顺序。

## 7. 每轮实验流程

每轮实验均采用相同流程：

~~~text
1. 停止上一轮 Ray Serve
2. 重新部署本轮 Serve 配置
3. flush 四个 SGLang backend
4. 执行 64 条 warmup request
5. 执行 2048 条 measured request
6. 保存完整 CSV / JSON 结果
~~~

切换不同 Router 时，需要确保上一轮 Serve 状态已经完全关闭。实验中使用：

~~~bash
python - <<'PY'
import ray
from ray import serve

ray.init(address="auto")
serve.shutdown()
ray.shutdown()

print("Serve shutdown complete")
PY
~~~

之后再启动下一轮 Deployment。

仅退出用于启动 Deployment 的 Python 脚本并不能保证 Serve 中已有 Router 状态被清除，因此切换路由策略时需要显式关闭 Serve。

## 8. Workload 回放

进入固定 workload 目录：

~~~bash
cd /root/autodl-tmp/HW3/26fall-HW-data/workloads/hw2/target3-routing-policies
ulimit -n 65535
~~~

以最终选定的 B32 为例：

~~~bash
python run_workload.py \
  --policy serve \
  --run-name B32_run1 \
  --router-name p2c \
  --max-ongoing-requests 32 \
  --base-url http://127.0.0.1:8000 \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 \
  --output-dir results/B32
~~~

有效实验需要满足：

~~~text
successful = 2048
failed = 0
incomplete = 0

warmup_successful = 64
warmup_failed = 0
warmup_incomplete = 0

validation_errors = []
~~~

同时 Replica、Node 和 Backend 均应覆盖 4 个实例。

## 9. 实验结果

| Round | Router | MOR | Success | Throughput (req/s) | Cache Hit | Actual Prefill Tokens | TTFT p95 (s) | E2E p95 (s) | Backend Distribution |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| A | P2C | 5 | 100% | 28.677 | 76.91% | 746432 | 43.050 | 44.533 | 509 / 529 / 501 / 509 |
| B16 | P2C | 16 | 100% | 18.475 | 76.29% | 766463 | 77.621 | 80.816 | 513 / 496 / 545 / 494 |
| B32 | P2C | 32 | 100% | 31.972 | 76.82% | 749568 | 33.329 | 37.016 | 508 / 499 / 526 / 515 |
| C | Consistent Hash | 32 | 100% | 13.277 | 94.90% | 164990 | 113.146 | 118.035 | 414 / 1042 / 241 / 351 |
| D | Affinity + Load-aware | 32 | 100% | 29.549 | 78.80% | 685568 | 39.155 | 42.456 | 495 / 503 / 491 / 559 |

B 的两个候选中最终选择 B32。

### 9.1 A 与 B

A 使用默认 `max_ongoing_requests=5`，吞吐量为 28.677 req/s，TTFT p95 为 43.050 s。

B16 将该参数提高到 16 后，吞吐反而下降到 18.475 req/s，TTFT p95 增加到 77.621 s。

B32 将该参数提高到 32 后，吞吐达到 31.972 req/s，TTFT p95 降到 33.329 s。因此两个 B 候选中选择 B32。

实验结果说明 `max_ongoing_requests` 并不是简单地越大或越小越好，它会与 Serve 的排队行为以及 SGLang 的 continuous batching 相互作用。

### 9.2 C：Prefix Affinity

C 使用 strict consistent hash 后：

~~~text
B32 Cache Hit Rate: 76.82%
C   Cache Hit Rate: 94.90%

B32 Actual Prefill Tokens: 749568
C   Actual Prefill Tokens: 164990
~~~

说明把同一 prefix family 稳定路由到同一个 backend 后，大量前缀 KV 能够被持续复用。

但是这种严格 affinity 同时产生了明显热点。

C 的整体 backend 分布：

~~~text
30000 -> 414
30001 -> 1042
30002 -> 241
30003 -> 351
~~~

其中 superhot family 一共有 768 个请求，全部进入同一个 backend：

~~~text
30001 -> 768
~~~

因此虽然缓存命中率明显提高，但单个 GPU 出现严重排队。

C 的整体吞吐量下降到 13.277 req/s，TTFT p95 增加到 113.146 s。

### 9.3 D：Affinity + Load-aware Spillover

D 保留 consistent hash 作为首选路由，但在 affinity primary 负载较高时允许请求转移到其他 Replica。

D 的整体 backend 分布：

~~~text
30000 -> 495
30001 -> 503
30002 -> 491
30003 -> 559
~~~

相比 C 已经明显更加均衡。

superhot family 的 768 个请求也由 C 的单 backend：

~~~text
C:
30001 -> 768
~~~

变为 D 中：

~~~text
D:
30000 -> 229
30001 -> 214
30002 -> 181
30003 -> 144
~~~

说明 load-aware spillover 成功缓解了 strict affinity 带来的热点。

D 的吞吐量恢复到 29.549 req/s，TTFT p95 降到 39.155 s，明显优于 C。

同时，D 的 Cache Hit Rate 为 78.80%，Actual Prefill Tokens 为 685568。

因此 D 相比 C 牺牲了一部分 Prefix Cache locality，但换来了更加均衡的 GPU 负载和明显更低的排队延迟。

D 并不要求所有指标都优于 B32，它主要展示了在 affinity 和负载均衡之间进行折中的一种可运行方案。

## 10. 结果目录

~~~text
results/target3/
├── A_default/
│   ├── config.json
│   ├── requests.csv
│   ├── summary.json
│   └── warmups.csv
├── B_candidates/
│   ├── B16/
│   │   ├── config.json
│   │   ├── requests.csv
│   │   ├── summary.json
│   │   └── warmups.csv
│   └── B32/
│       ├── config.json
│       ├── requests.csv
│       ├── summary.json
│       └── warmups.csv
├── C_affinity/
│   ├── config.json
│   ├── requests.csv
│   ├── summary.json
│   └── warmups.csv
└── D_improved/
    ├── config.json
    ├── requests.csv
    ├── summary.json
    └── warmups.csv
~~~

报告主表中的数据分别对应：

~~~text
A   -> results/target3/A_default/summary.json
B16 -> results/target3/B_candidates/B16/summary.json
B32 -> results/target3/B_candidates/B32/summary.json
C   -> results/target3/C_affinity/summary.json
D   -> results/target3/D_improved/summary.json
~~~

逐请求结果位于对应目录下的 `requests.csv`。

## 11. 源码说明

~~~text
src/target3/
├── start_ray_cluster.py
├── serve_a.py
├── serve_b16.py
├── serve_b32.py
├── serve_c.py
├── serve_d.py
├── hybrid_router.py
└── node_backend_map.json
~~~

各文件作用：

- `start_ray_cluster.py`：创建 1 个 head 和 4 个逻辑 worker，并生成 Node ID 与 SGLang backend 的映射；
- `serve_a.py`：A 组默认 P2C，MOR=5；
- `serve_b16.py`：B 候选，MOR=16；
- `serve_b32.py`：B 候选，MOR=32；
- `serve_c.py`：使用 ConsistentHashRouter 实现 prefix affinity；
- `serve_d.py`：部署自定义改进 Router；
- `hybrid_router.py`：Affinity + Load-aware Spillover 的具体实现；
- `node_backend_map.json`：Ray worker Node ID 与 SGLang backend 的对应关系。

## 12. 最终提交目录

根据课程群补充说明，本次不需要额外加入第二次挑战的 target1 内容。

最终提交目录：

~~~text
HW3-姓名（或学号）/
├── README.md
├── report.pdf
├── AI 使用说明情况（第三次挑战）.pdf
├── src/
│   └── target3/
│       ├── start_ray_cluster.py
│       ├── serve_a.py
│       ├── serve_b16.py
│       ├── serve_b32.py
│       ├── serve_c.py
│       ├── serve_d.py
│       ├── hybrid_router.py
│       └── node_backend_map.json
└── results/
    └── target3/
        ├── A_default/
        ├── B_candidates/
        │   ├── B16/
        │   └── B32/
        ├── C_affinity/
        └── D_improved/
~~~

提交中不包含模型权重、Python 虚拟环境、安装包以及 `__pycache__` 等缓存目录。
